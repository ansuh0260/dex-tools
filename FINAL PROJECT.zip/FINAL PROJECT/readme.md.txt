step 1 : download zip file 
step 2 : unzip the file in new folder
step 3 : install python in your system 
step 4 : install flask python library 
        To dowdownload flask library in your system 
        step 1 : open terminal 
        step 2 : type this command 
                $ pip install flask
step 5 : app.py in your system 

thank you >>>>>>>>>>>>>>>>>>>>>>>>
